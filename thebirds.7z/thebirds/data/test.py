import sqlite3

conn = sqlite3.connect('bird.db')
print("Opened database successfully");

cursor = conn.execute("SELECT name, Latin_Name, Family, Conservation_Status, Region, Color from tab1")
#for row in cursor:
#	print("Name = ", row[0])
#	print("Family = ", row[1], "\n")

matches = 0
print("Operation done successfully");
bird = input("Enter the name of a bird you would like to search for: ")
for row in cursor:
	if (row[0].lower().find(bird.lower())!=-1):
		print("Name: ", row[0])
		print("Latin Name: ", row[1])
		print("Family: ", row[2])
		print("Conservation Status: ", row[3])
		print("Region(s):", row[4])
		print("Color(s):", row[5], "\n")
		matches+=1;

print(matches, "matches found","\n")
conn.close()

conn = sqlite3.connect('bird.db')
cursor = conn.execute("SELECT name, Latin_Name, Family, Conservation_Status, Region, Color from tab1")
matches = 0
color = input("Enter the color of a bird you would like to search for: ")
region = input("Enter the region of a bird you would like to search for: ")
for row in cursor:
	if (row[5].lower().find(color.lower())!=-1): 
		if(row[4].lower().find(region.lower())!=-1):
			print("Name: ", row[0])
			print("Latin Name: ", row[1])
			print("Family: ", row[2])
			print("Conservation Status: ", row[3])
			print("Region(s):", row[4])
			print("Color(s):", row[5], "\n")
			matches+=1;

print(matches, "matches found","\n")
	
conn.close()
