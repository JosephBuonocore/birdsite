import sqlite3

conn = sqlite3.connect('userbase.db')
print("Opened database successfully");

us = "dummy"
bi = input("What is the name of the bird you saw? ")
da = input("What date did you see it? " )
lo = input("Where did you see it?" )

new = (us,bi,da,lo)

conn.execute("INSERT INTO tab1 (NAME,BIRD,DAY,LOCATION) VALUES(?,?,?,?)",new)
#conn.commit() #uncomment if you want changes to be permanent

cursor = conn.execute("SELECT name, bird, day, location from tab1")
for row in cursor:
	print("Username = ", row[0])
	print("Bird = ", row[1])
	print("Date = ", row[2])
	print("Location = ", row[3], "\n")

conn.close()
