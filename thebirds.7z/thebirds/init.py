from flask import Flask, render_template, redirect, url_for, request
import sqlite3 as sql
app = Flask(__name__)

@app.route("/hello")
def hello():
    return "Hello World!"

@app.route("/")
def home():
    return redirect(url_for('index'))

@app.route("/index")
def index():
	return render_template('index.html')

@app.route("/search")
def search():
	return render_template('search.html')

@app.route("/nearby")
def nearby():
	return render_template('nearby.html')

@app.route("/profile")
def profile():
	return render_template('profile.html')
#@app.route("/profile/<user>")
#def profile(user):
#	return render_template('profile.html',user=user)

@app.route("/listbirds")
def listbirds():
	con = sql.connect('data/bird.db')
	con.row_factory = sql.Row

	cur = con.cursor()
	cur.execute("select * from tab1")

	rows = cur.fetchall();
	return render_template("list.html",rows=rows)

if __name__ == "__main__":
    app.run()